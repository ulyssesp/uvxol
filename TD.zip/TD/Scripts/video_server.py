# me - this DAT.
# webServerDAT - the connected Web Server DAT
# request - A dictionary of the request fields. The dictionary will always contain the below entries, plus any additional entries dependent on the contents of the request
# 		'method' - The HTTP method of the request (ie. 'GET', 'PUT').
# 		'uri' - The client's requested URI.
# 		'clientAddress' - The client's address.
# 		'serverAddress' - The server's address.
# response - A dictionary defining the response, to be filled in during the request method. Additional fields not specified below can be added (eg. response['content-type'] = 'application/json').
# 		'statusCode' - A valid HTTP status code integer (ie. 200, 401, 404). Default is 404.
# 		'statusReason' - The reason for the above status code being returned (ie. 'Not Found.').
# 		'data' - The data to send back to the client. If displaying a web-page, any HTML would be put here.
# return the response dictionary

import td
import json
from urllib.parse import parse_qs

def onHTTPRequest(webServerDAT, request, response):
  playFile(request['pars']['location'], request['pars']['filePath'])

  response['statusCode'] = 200 # OK
  response['statusReason'] = 'OK'
  response['data'] = '<b>TouchDesigner: </b>' + webServerDAT.name
  response['Access-Control-Allow-Origin'] = '*'
  return response

def onWebSocketOpen(webServerDAT, client):
	webServerDAT.webSocketSendText(client, "hi?")
	return

def onWebSocketReceiveText(webServerDAT, client, data):
	data = json.loads(data)
	playFile(data['location'], data['filePath'])
	return

def onWebSocketReceiveBinary(webServerDAT, client, data):
	print("receive binary")
	webServerDAT.webSocketSendBinary(client, data)
	return

def onServerStart(webServerDAT):
	return

def onServerStop(webServerDAT):
	return

def playFile(location, filePath):
  playingFiles = op("playing_files")

  try:
    playingFiles[location, 1] = 'video/' + filePath
  except:
    print(location)
    print(filePath)