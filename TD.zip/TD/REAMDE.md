Open up Screens.toe
Open up Twitch.toe
Go to `https://uvxolweb.z13.web.core.windows.net/#/runner` in your favorite browser
Have fun!
Really, have fun or LUX will destroy you.